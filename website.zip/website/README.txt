Tässä on kaksi itsenäistä sivua:
- intra-sivu (intra kansiossa)
- etusivu

Molemmat sivut käyttävät tietokantaa, johon sivusto yhdistää index.php:n kautta (käyttäjänimi ja salasana), itse tietokannan nimi määritellään "db/connection.php" -tiedostossa.

Ohjeita sivun käyttöön:
Intrasivulle pääsee, kun kirjoittaa osoite palkkiin: /intra (Salasana: admin, käyttäjätunnus: taitaja2022)
Intrasivulla voi lisätä, muokata ja poistaa matkoja.
Kun matkan lisää, se näkyy automaattisesti etusivun kartalla.
