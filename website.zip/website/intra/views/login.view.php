<?php

echo "
<form method='post'>
<label>Käyttäjänimi</label>    
<input type='text' name='user'>
<label>Salasana</label>    
<input type='password' name='pass'>
<input type='submit' value='Kirjaudu'>
</form>
";